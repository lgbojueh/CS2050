import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Program6 {
    private static final Logger LOGGER = Logger.getLogger(Program6.class.getName());

    public static void main(String[] args) {
        try {
            // Use logger to write logs to a file
            FileHandler fileHandler = new FileHandler("sorting.log");
            LOGGER.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);

            // Part 1: Sorting Integer Arrays
            int[] bubbleSortArray = new int[20000];
            int[] selectionSortArray = new int[20000];

            try (BufferedReader br = new BufferedReader(new FileReader("NumbersInFile.txt"))) {
                String line;
                int index = 0;
                while ((line = br.readLine()) != null && index < 20000) {
                    int number = Integer.parseInt(line);
                    bubbleSortArray[index] = number;
                    selectionSortArray[index] = number;
                    index++;
                }
            } catch (IOException e) {
                LOGGER.severe("Error reading data from file: " + e.getMessage());
                return;
            }

            long bubbleSortStartTime = System.nanoTime();
            bubbleSort(bubbleSortArray);
            long bubbleSortEndTime = System.nanoTime();
            long bubbleSortTime = bubbleSortEndTime - bubbleSortStartTime;

            long selectionSortStartTime = System.nanoTime();
            selectionSort(selectionSortArray);
            long selectionSortEndTime = System.nanoTime();
            long selectionSortTime = selectionSortEndTime - selectionSortStartTime;

            // Part 2: Sorting String Arrays and ArrayList
            String[] bubbleSortStringArray = new String[20000];
            String[] selectionSortStringArray = new String[20000];

            try (BufferedReader br = new BufferedReader(new FileReader("NumbersInFile.txt"))) {
                String line;
                int index = 0;
                while ((line = br.readLine()) != null && index < 20000) {
                    bubbleSortStringArray[index] = line;
                    selectionSortStringArray[index] = line;
                    index++;
                }
            } catch (IOException e) {
                LOGGER.severe("Error reading data from file: " + e.getMessage());
                return;
            }

            long bubbleSortStringStartTime = System.nanoTime();
            bubbleSort(bubbleSortStringArray);
            long bubbleSortStringEndTime = System.nanoTime();
            long bubbleSortStringTime = bubbleSortStringEndTime - bubbleSortStringStartTime;

            long selectionSortStringStartTime = System.nanoTime();
            selectionSort(selectionSortStringArray);
            long selectionSortStringEndTime = System.nanoTime();
            long selectionSortStringTime = selectionSortStringEndTime - selectionSortStringStartTime;

            // Sorting an ArrayList of Strings
            ArrayList<String> stringArrayList = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader("NumbersInFile.txt"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    stringArrayList.add(line);
                }
            } catch (IOException e) {
                LOGGER.severe("Error reading data from file: " + e.getMessage());
                return;
            }

            long collectionSortStartTime = System.nanoTime();
            Collections.sort(stringArrayList);
            long collectionSortEndTime = System.nanoTime();
            long collectionSortTime = collectionSortEndTime - collectionSortStartTime;

            // Results to results.txt
            try (FileWriter writer = new FileWriter("results.txt")) {
                // Integer sorting results
                writer.write("Integer Array Bubble Sort Time: " + bubbleSortTime + " ns\n");
                writer.write("Integer Array Selection Sort Time: " + selectionSortTime + " ns\n");

                // String sorting results
                writer.write("String Array Bubble Sort Time: " + bubbleSortStringTime + " ns\n");
                writer.write("String Array Selection Sort Time: " + selectionSortStringTime + " ns\n");
                writer.write("ArrayList Collection Sort Time: " + collectionSortTime + " ns\n");
            } catch (IOException e) {
                LOGGER.severe("Error writing results to file: " + e.getMessage());
            }
        } catch (IOException e) {
            LOGGER.severe("Error setting up logger: " + e.getMessage());
        }
    }

    // Bubble Sort for Integer and String arrays
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        boolean swapped;
        do {
            swapped = false;
            for (int i = 1; i < n; i++) {
                if (arr[i - 1] > arr[i]) {
                    // Swap arr[i-1] and arr[i]
                    int temp = arr[i - 1];
                    arr[i - 1] = arr[i];
                    arr[i] = temp;
                    swapped = true;
                }
            }
            n--;
        } while (swapped);
    }

    public static void bubbleSort(String[] arr) {
        int n = arr.length;
        boolean swapped;
        do {
            swapped = false;
            for (int i = 1; i < n; i++) {
                if (arr[i - 1].compareTo(arr[i]) > 0) {
                    // Swap arr[i-1] and arr[i]
                    String temp = arr[i - 1];
                    arr[i - 1] = arr[i];
                    arr[i] = temp;
                    swapped = true;
                }
            }
            n--;
        } while (swapped);
    }

    // Selection Sort for Integer and String arrays
    public static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            // Swap arr[i] and arr[minIndex]
            int temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }

    public static void selectionSort(String[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j].compareTo(arr[minIndex]) < 0) {
                    minIndex = j;
                }
            }
            // Swap arr[i] and arr[minIndex]
            String temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
    }
}
