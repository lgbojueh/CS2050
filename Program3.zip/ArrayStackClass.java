/*
 * Leo Gbojueh
 * ArrayStackClass.java
 */

import java.util.EmptyStackException;

public class ArrayStackClass<T> {
    private Object[] stackArray;
    private int top;
    private int capacity;

    public ArrayStackClass(int capacity) {
        this.capacity = capacity;
        this.stackArray = new Object[capacity];
        this.top = -1;
    }

    public void push(T element) {
        if (isFull()) {
            throw new StackOverflowError("Stack is full.");
        }
        stackArray[++top] = element;
    }

    public T pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        T element = (T) stackArray[top];
        stackArray[top--] = null; // Remove the reference to the popped element
        return element;
    }

    public T peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return (T) stackArray[top];
    }

    public boolean empty() {
        return top == -1;
    }

    public int size() {
        return top + 1;
    }

    private boolean isFull() {
        return top == capacity - 1;
    }

    private boolean isEmpty() {
        return top == -1;
    }

    public static void main(String[] args) {
        // Example usage of ArrayStackClass
        ArrayStackClass<Integer> stack = new ArrayStackClass<>(5);

        stack.push(1);
        stack.push(2);
        stack.push(3);

        System.out.println("Size of the stack: " + stack.size());
        System.out.println("Top element of the stack: " + stack.peek());

        System.out.println("Popping elements from the stack:");
        while (!stack.empty()) {
            System.out.println(stack.pop());
        }

        System.out.println("Is the stack empty? " + stack.empty());
    }
}
