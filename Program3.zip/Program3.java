import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.EmptyStackException;

public class Program3 {
    public static void main(String[] args) {
        String[] expressions = {
                "4 + 6 * 3.1",
                "4 + (6 * 3.1)",
                "(4 + 6) * 3.1",
                "2 + 3 * 4",
                "2 & 3 @ 4",
                "2 + 3 % 4",
                "2.0 + 3 * 4",
                "(2.0 + 3 / 4)",
                "3 + 4 * 2 / (1 - 5)",
                "3 + 4.0 * 2 / (1.0 - 5)",
                "42 / 9.2 / 3.1 * 6",
                "" // Handling empty expression
        };

        String outputFile = "Program3.out";

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            for (String infix : expressions) {
                try {
                    if (!infix.isEmpty()) { // Skip empty expressions
                        String postfix = InfixToPostfix(infix);
                        writer.write(infix + " -> " + postfix);
                    } else {
                        writer.write("Empty expression -> Invalid expression");
                    }
                } catch (EmptyStackException e) {
                    writer.write(infix + " -> Invalid expression");
                }
                writer.newLine();
            }
            System.out.println("Conversion completed. Output written to " + outputFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static String InfixToPostfix(String s) {
        StringBuilder postfix = new StringBuilder();
        char[] stack = new char[s.length()]; // Custom stack
        int top = -1; // Stack top pointer

        for (char c : s.toCharArray()) {
            if (Character.isDigit(c) || c == '.') {
                postfix.append(c);
            } else if (c == '(') {
                stack[++top] = c;
            } else if (c == ')') {
                while (top >= 0 && stack[top] != '(') {
                    postfix.append(' ');
                    postfix.append(stack[top--]);
                }
                if (top >= 0 && stack[top] == '(') {
                    top--; // Pop '('
                } else {
                    throw new EmptyStackException();
                }
            } else if (isOperator(c)) { // Check if it's a valid operator
                while (top >= 0 && getPrecedence(stack[top]) >= getPrecedence(c)) {
                    if (stack[top] == '(') {
                        break;
                    }
                    postfix.append(' ');
                    postfix.append(stack[top--]);
                }
                stack[++top] = c; // Push current operator
                postfix.append(' ');
            }
        }

        while (top >= 0) {
            if (stack[top] == '(') {
                throw new EmptyStackException();
            }
            postfix.append(' ');
            postfix.append(stack[top--]);
        }

        return postfix.toString().trim();
    }

    private static int getPrecedence(char operator) {
        switch (operator) {
            case '+':
            case '-':
                return 1;
            case '*':
            case '/':
                return 2;
            default:
                return 0;
        }
    }

    private static boolean isOperator(char c) {
        return c == '+' || c == '-' || c == '*' || c == '/';
    }
}