/*
 * Leo Gbojueh
 * Program5.java
 * Stack
 */

import java.io.*;
import java.util.EmptyStackException;
import java.util.Stack;

public class Program5 {
    public static void main(String[] args) {
        String inputFile = "Program5.txt";
        String outputFile = "Program5.out";

        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(outputFile))) {
            String infix;
            while ((infix = reader.readLine()) != null) {
                try {
                    if (!infix.isEmpty()) {
                        String postfix = infixToPostfix(infix);
                        Stack<String> stack = new Stack<>(); // Create a stack

                        for (String token : postfix.split("\\s+")) {
                            if (isOperand(token)) {
                                stack.push(token);
                            } else if (isOperator(token)) {
                                String operand2 = stack.pop();
                                String operand1 = stack.pop();
                                String result = operand1 + " " + operand2 + " " + token;
                                stack.push(result);
                            }
                        }

                        writer.write(infix + " -> " + stack.pop());
                    } else {
                        writer.write("Empty expression -> Invalid expression");
                    }
                } catch (EmptyStackException e) {
                    writer.write(infix + " -> Invalid expression");
                }
                writer.newLine();
            }
            System.out.println("Conversion completed. Output written to " + outputFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public static String infixToPostfix(String s) {
        StringBuilder postfix = new StringBuilder();
        Stack<Character> stack = new Stack<>(); // Create a stack for operators

        for (char c : s.toCharArray()) {
            if (Character.isDigit(c) || c == '.') {
                postfix.append(c);
            } else if (c == '(') {
                stack.push(c);
            } else if (c == ')') {
                while (!stack.isEmpty() && stack.peek() != '(') {
                    postfix.append(' ');
                    postfix.append(stack.pop());
                }
                if (!stack.isEmpty() && stack.peek() == '(') {
                    stack.pop();
                } else {
                    throw new EmptyStackException();
                }
            } else if (isOperator(String.valueOf(c))) {
                while (!stack.isEmpty() && getPrecedence(stack.peek()) >= getPrecedence(c)) {
                    if (stack.peek() == '(') {
                        break;
                    }
                    postfix.append(' ');
                    postfix.append(stack.pop());
                }
                stack.push(c);
                postfix.append(' ');
            }
        }

        while (!stack.isEmpty()) {
            if (stack.peek() == '(') {
                throw new EmptyStackException();
            }
            postfix.append(' ');
            postfix.append(stack.pop());
        }

        return postfix.toString().trim();
    }

    private static boolean isOperand(String token) {
        try {
            Double.parseDouble(token);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private static boolean isOperator(String token) {
        return token.matches("[+\\-*/]");
    }

    private static int getPrecedence(char operator) {
        return switch (operator) {
            case '+', '-' -> 1;
            case '*', '/' -> 2;
            default -> 0;
        };
    }
}



