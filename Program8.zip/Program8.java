/*
 * Leo Gbojueh
 * 11/05/23
 * Program8.java
 * BST Trees
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Logger;

// TreeNode class
class TreeNode {
    String word;
    TreeNode left;
    TreeNode right;

    public TreeNode(String word) {
        this.word = word;
        this.left = null;
        this.right = null;
    }
}

// BinarySearchTree class
class BinarySearchTree {
    TreeNode root;

    public BinarySearchTree() {
        this.root = null;
    }

    // Insert word into BST
    public void insert(String word) {
        if (root == null) {
            root = new TreeNode(word);
        } else {
            insertRecursive(root, word);
        }
    }

    // Recursively insert word into BST
    private void insertRecursive(TreeNode current, String word) {
        if (word.compareTo(current.word) < 0) {
            if (current.left == null) {
                current.left = new TreeNode(word);
            } else {
                insertRecursive(current.left, word);
            }
        } else if (word.compareTo(current.word) > 0) {
            if (current.right == null) {
                current.right = new TreeNode(word);
            } else {
                insertRecursive(current.right, word);
            }
        }
    }
}

public class Program8 {
    private static final Logger logger = Logger.getLogger(Program8.class.getName());

    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();

        try {
            // Read "dracula.txt" file
            BufferedReader reader = new BufferedReader(new FileReader("dracula.txt"));
            String line;

            // Process each line of the file
            while ((line = reader.readLine()) != null) {
                // Split line into words, convert to lowercase, and insert into BST
                String[] words = line.split("[\\s\\p{Punct}\\d]+");
                for (String word : words) {
                    if (!word.isEmpty()) {
                        word = word.toLowerCase();
                        bst.insert(word);
                    }
                }
            }

            reader.close();
            // Calculate and write the analysis to "analysis.txt"
            int numberOfNodes = countNodes(bst.root);
            int longestPath = findLongestPath(bst.root);

            FileWriter writer = new FileWriter("analysis.txt");
            writer.write("Number of nodes: " + numberOfNodes + "\n");
            writer.write("Longest path in the tree: " + longestPath + "\n");
            writer.close();

            System.out.println("Analysis written to analysis.txt");

        } catch (IOException e) {
            logger.severe("An error occurred while processing the file: " + e.getMessage());
        }
    }

    // Count number of nodes in BST
    private static int countNodes(TreeNode node) {
        if (node == null) {
            return 0;
        }
        return 1 + countNodes(node.left) + countNodes(node.right);
    }

    // Find the longest path 
    private static int findLongestPath(TreeNode node) {
        if (node == null) {
            return 0;
        }

        int leftPath = findLongestPath(node.left);
        int rightPath = findLongestPath(node.right);

        // Return the longer path from the left and right subtrees
        return 1 + Math.max(leftPath, rightPath);
    }
}