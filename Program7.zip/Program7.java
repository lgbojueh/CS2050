/*
 * Leo Gbojueh
 * Program 7
 * Insertion Sort
 * 10/15/23
 */

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;
import java.util.logging.FileHandler;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

public class Program7 {
    private static final Logger LOGGER = Logger.getLogger(Program7.class.getName());

    public static void main(String[] args) {
        try {
            // Set up logger to log events
            FileHandler fileHandler = new FileHandler("sorting.log");
            LOGGER.addHandler(fileHandler);
            SimpleFormatter formatter = new SimpleFormatter();
            fileHandler.setFormatter(formatter);

            // Part 1: Sorting Integer Arrays
            int[] bubbleSortArray = new int[20000];
            int[] selectionSortArray = new int[20000];
            int[] insertionSortArray = new int[20000];

            try (BufferedReader br = new BufferedReader(new FileReader("NumbersInFile.txt"))) {
                String line;
                int index = 0;
                while ((line = br.readLine()) != null && index < 20000) {
                    int number = Integer.parseInt(line);
                    bubbleSortArray[index] = number;
                    selectionSortArray[index] = number;
                    insertionSortArray[index] = number;
                    index++;
                }
            } catch (IOException e) {
                LOGGER.severe("Error reading data from file: " + e.getMessage());
                return;
            }

            // Timing the sorting algorithms for the integer arrays
            long bubbleSortStartTime = System.nanoTime();
            bubbleSort(bubbleSortArray);
            long bubbleSortEndTime = System.nanoTime();
            long bubbleSortTime = bubbleSortEndTime - bubbleSortStartTime;

            long selectionSortStartTime = System.nanoTime();
            selectionSort(selectionSortArray);
            long selectionSortEndTime = System.nanoTime();
            long selectionSortTime = selectionSortEndTime - selectionSortStartTime;

            long insertionSortStartTime = System.nanoTime();
            insertionSort(insertionSortArray);
            long insertionSortEndTime = System.nanoTime();
            long insertionSortTime = insertionSortEndTime - insertionSortStartTime;

            // Part 2: Sorting String Arrays and ArrayList
            String[] bubbleSortStringArray = new String[20000];
            String[] selectionSortStringArray = new String[20000];
            String[] insertionSortStringArray = new String[20000];

            try (BufferedReader br = new BufferedReader(new FileReader("StringsInFile"))) {
                String line;
                int index = 0;
                while ((line = br.readLine()) != null && index < 20000) {
                    bubbleSortStringArray[index] = line;
                    selectionSortStringArray[index] = line;
                    insertionSortStringArray[index] = line;
                    index++;
                }
            } catch (IOException e) {
                LOGGER.severe("Error reading data from file: " + e.getMessage());
                return;
            }

            // Filter out null values from the String arrays
            bubbleSortStringArray = Arrays.stream(bubbleSortStringArray)
                    .filter(Objects::nonNull)
                    .toArray(String[]::new);

            selectionSortStringArray = Arrays.stream(selectionSortStringArray)
                    .filter(Objects::nonNull)
                    .toArray(String[]::new);

            insertionSortStringArray = Arrays.stream(insertionSortStringArray)
                    .filter(Objects::nonNull)
                    .toArray(String[]::new);

            long bubbleSortStringStartTime = System.nanoTime();
            Arrays.sort(bubbleSortStringArray);
            long bubbleSortStringEndTime = System.nanoTime();
            long bubbleSortStringTime = bubbleSortStringEndTime - bubbleSortStringStartTime;

            long selectionSortStringStartTime = System.nanoTime();
            Arrays.sort(selectionSortStringArray);
            long selectionSortStringEndTime = System.nanoTime();
            long selectionSortStringTime = selectionSortStringEndTime - selectionSortStringStartTime;

            long insertionSortStringStartTime = System.nanoTime();
            Arrays.sort(insertionSortStringArray);
            long insertionSortStringEndTime = System.nanoTime();
            long insertionSortStringTime = insertionSortStringEndTime - insertionSortStringStartTime;

            // Sorting an ArrayList of Strings
            ArrayList<String> stringArrayList = new ArrayList<>();
            try (BufferedReader br = new BufferedReader(new FileReader("StringsInFile"))) {
                String line;
                while ((line = br.readLine()) != null) {
                    stringArrayList.add(line);
                }
            } catch (IOException e) {
                LOGGER.severe("Error reading data from file: " + e.getMessage());
                return;
            }

            long collectionSortStartTime = System.nanoTime();
            Collections.sort(stringArrayList);
            long collectionSortEndTime = System.nanoTime();
            long collectionSortTime = collectionSortEndTime - collectionSortStartTime;

            // Results to results.txt
            try (FileWriter writer = new FileWriter("results.txt")) {
                // Integer sorting results
                writer.write("Integer Array Bubble Sort Time: " + bubbleSortTime + " ns\n");
                writer.write("Integer Array Selection Sort Time: " + selectionSortTime + " ns\n");
                writer.write("Integer Array Insertion Sort Time: " + insertionSortTime + " ns\n");

                // String sorting results
                writer.write("String Array Bubble Sort Time: " + bubbleSortStringTime + " ns\n");
                writer.write("String Array Selection Sort Time: " + selectionSortStringTime + " ns\n");
                writer.write("String Array Insertion Sort Time: " + insertionSortStringTime + " ns\n");

                writer.write("ArrayList Collection Sort Time: " + collectionSortTime + " ns\n");
            } catch (IOException e) {
                LOGGER.severe("Error writing results to file: " + e.getMessage());
            }
        } catch (IOException e) {
            LOGGER.severe("Error setting up logger: " + e.getMessage());
        }
    }

    // Bubble Sort for Integer arrays
    public static void bubbleSort(int[] arr) {
        int n = arr.length;
        boolean swapped;
        do {
            swapped = false;
            for (int i = 1; i < n; i++) {
                if (arr[i - 1] > arr[i]) {
                    // Swap arr[i-1] and arr[i]
                    int temp = arr[i - 1];
                    arr[i - 1] = arr[i];
                    arr[i] = temp;
                    swapped = true;
                }
            }
            n--;
        } while (swapped);
    }

    // Insertion Sort for Integer arrays
    public static void insertionSort(int[] arr) {
        int n = arr.length;
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j = j - 1;
            }
            arr[j + 1] = key;
        }
    }

    // Selection Sort for Integer arrays
    public static void selectionSort(int[] arr) {
        int n = arr.length;
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
        }
    }
}