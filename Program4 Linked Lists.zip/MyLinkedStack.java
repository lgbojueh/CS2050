public class MyLinkedStack {
    private Node top; // Top of the stack

    // Node class for holding strings
    private class Node {
        String data;
        Node next;

        Node(String data) {
            this.data = data;
            this.next = null;
        }
    }

    // Push a string onto the stack
    public void push(String data) {
        Node newNode = new Node(data);
        newNode.next = top;
        top = newNode;
    }

    // Pop a string from the stack and return it
    public String pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }

        String poppedData = top.data;
        top = top.next;
        return poppedData;
    }

    // Check if the stack is empty
    public boolean isEmpty() {
        return top == null;
    }

    // Peek at the top element of the stack without removing it
    public String peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }

        return top.data;
    }
}
