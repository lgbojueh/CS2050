/*
 * Leo Gbojueh
 * Program #2
 */

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    private static final double DELTA = 1. / 10000;

    @Test
    public void testZeroAddZero() {
        assertEquals(0, Main.add(0, 0));
    }

    @Test
    public void testZeroAddPositive() {
        assertEquals(5, Main.add(0, 5));
    }

    @Test
    public void testPositiveAddZero() {
        assertEquals(5, Main.add(5, 0));
    }

    @Test
    public void testPositiveAddPositive() {
        assertEquals(7, Main.add(5, 2));
        assertEquals(7, Main.add(2, 5));
    }

    @Test
    public void testZeroAddNegative() {
        assertEquals(-5, Main.add(0, -5));
    }

    @Test
    public void testNegativeAddZero() {
        assertEquals(-5, Main.add(-5, 0));
    }

    @Test
    public void testNegativeAddNegative() {
        assertEquals(-7, Main.add(-5, -2));
        assertEquals(-7, Main.add(-2, -5));
    }

    @Test
    public void testPositiveAddNegative() {
        assertEquals(3, Main.add(5, -2));
    }

    @Test
    public void testNegativeAddPositive() {
        assertEquals(-3, Main.add(-5, 2));
    }

    @Test
    public void testZeroSubtractZero() {
        assertEquals(0, Main.subtract(0, 0));
    }

    @Test
    public void testZeroSubtractPositive() {
        assertEquals(-5, Main.subtract(0, 5));
    }

    @Test
    public void testPositiveSubtractZero() {
        assertEquals(5, Main.subtract(5, 0));
    }

    @Test
    public void testPositiveSubtractPositive() {
        assertEquals(3, Main.subtract(5, 2));
        assertEquals(-3, Main.subtract(2, 5));
    }

    @Test
    public void testZeroSubtractNegative() {
        assertEquals(5, Main.subtract(0, -5));
    }

    @Test
    public void testNegativeSubtractZero() {
        assertEquals(-5, Main.subtract(-5, 0));
    }

    @Test
    public void testNegativeSubtractNegative() {
        assertEquals(-3, Main.subtract(-5, -2));
        assertEquals(3,Main.subtract(-2, -5));
    }

    @Test
    public void testPositiveSubtractNegative() {
        assertEquals(7, Main.subtract(5, -2));
    }

    @Test
    public void testNegativeSubtractPositive() {
        assertEquals(-7, Main.subtract(-5, 2));
    }

    @Test
    public void testZeroMultiplyZero() {
        assertEquals(0, Main.multiply(0, 0));
    }

    @Test
    public void testZeroMultiplyPositive() {
        assertEquals(0, Main.multiply(0, 5));
    }

    @Test
    public void testPositiveMultiplyZero() {
        assertEquals(0, Main.multiply(5, 0));
    }

    @Test
    public void testPositiveMultiplyPositive() {
        assertEquals(10, Main.multiply(5, 2));
        assertEquals(10, Main.multiply(2, 5));
    }

    @Test
    public void testZeroMultiplyNegative() {
        assertEquals(0, Main.multiply(0, -5));
    }

    @Test
    public void testNegativeMultiplyZero() {
        assertEquals(0, Main.multiply(-5, 0));
    }

    @Test
    public void testNegativeMultiplyNegative() {
        assertEquals(10, Main.multiply(-5, -2));
        assertEquals(10, Main.multiply(-2, -5));
    }

    @Test
    public void testPositiveMultiplyNegative() {
        assertEquals(-10, Main.multiply(5, -2));
    }

    @Test
    public void testNegativeMultiplyPositive() {
        assertEquals(-10, Main.multiply(-5, 2));
    }

    @Test
    public void testZeroDivideZero() {
        assertThrows(ArithmeticException.class, () -> Main.divide(0, 0));
    }

    @Test
    public void testZeroDividePositive() {
        assertEquals(0, Main.divide(0, 5), DELTA);
    }

    @Test
    public void testPositiveDivideZero() {
        assertThrows(ArithmeticException.class, () -> Main.divide(5, 0));
    }

    @Test
    public void testPositiveDividePositive() {
        assertEquals(2.5, Main.divide(5, 2), DELTA);
        assertEquals(0.4, Main.divide(2, 5), DELTA);
    }

    @Test
    public void testZeroDivideNegative() {
        assertEquals(0, Main.divide(0, -5), DELTA);
    }

    @Test
    public void testNegativeDivideZero() {
        assertThrows(ArithmeticException.class, () -> Main.divide(-5, 0));
    }

    @Test
    public void testNegativeDivideNegative() {
        assertEquals(2.5, Main.divide(-5, -2), DELTA);
        assertEquals(0.4, Main.divide(-2, -5), DELTA);
    }

    @Test
    public void testPositiveDivideNegative() {
        assertEquals(-2.5, Main.divide(5, -2), DELTA);
    }

    @Test
    public void testNegativeDividePositive() {
        assertEquals(-2.5, Main.divide(-5, 2), DELTA);
    }
}