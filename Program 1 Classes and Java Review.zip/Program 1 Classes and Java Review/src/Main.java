/*
Albums.java
Program #1 - Classes & Java Review
----------------------------------

Author: Leo Gbojueh
Email: lgbojueh@msudenver.com
Date: 09/10/2021
---------------------------------
 */
import java.util.Scanner;

public class Main {
    // Class variables with default values
    private static String defaultTitle = "Renaissance";
    private static String defaultPerformer = "Beyonce";
    private static int defaultNumberOfSongs = 10;
    private static String defaultGenre = "easy listening";

    // Instance variables
    private String title;
    private String performer;
    private String genre;
    private int numberOfSongs;

    // Default constructor
    public Main() {
        this.title = defaultTitle;
        this.performer = defaultPerformer;
        this.genre = defaultGenre;
        this.numberOfSongs = defaultNumberOfSongs;
    }

    // Parameterized constructor
    public Main(String title, String performer, String genre, int numberOfSongs) {
        this.title = title;
        this.performer = performer;
        setGenre(genre); // Use setter to ensure a valid genre
        this.numberOfSongs = numberOfSongs;
    }

    // Getter and Setter methods for title
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    // Getter and Setter methods for performer
    public String getPerformer() {
        return performer;
    }

    public void setPerformer(String performer) {
        this.performer = performer;
    }

    // Getter and Setter methods for genre with validation
    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        // Validate and set to "easy listening" if not a valid genre
        if (isValidGenre(genre)) {
            this.genre = genre;
        } else {
            this.genre = "easy listening";
        }
    }

    // Getter and Setter methods for numberOfSongs
    public int getNumberOfSongs() {
        return numberOfSongs;
    }

    public void setNumberOfSongs(int numberOfSongs) {
        this.numberOfSongs = numberOfSongs;
    }

    // Check if the album has more than 50 songs
    public boolean isLong() {
        return numberOfSongs > 50;
    }

    // Method to validate if a genre is valid
    private boolean isValidGenre(String genre) {
        return genre.equals("hip-hop") || genre.equals("easy listening") || genre.equals("orchestral") || genre.equals("theatre");
    }

    // toString method to represent the album as a string
    @Override
    public String toString() {
        return "Album Title: " + title + "\nPerformer: " + performer + "\nGenre: " + genre + "\nNumber of Songs: " + numberOfSongs;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create three Album objects
        Main album1 = createAlbum(scanner, 1);
        Main album2 = createAlbum(scanner, 2);
        Main album3 = createAlbum(scanner, 3);

        // Display album information
        System.out.println("\nAlbum 1:");
        System.out.println(album1.toString());
        System.out.println("\nAlbum 2:");
        System.out.println(album2.toString());
        System.out.println("\nAlbum 3:");
        System.out.println(album3.toString());

        scanner.close();
    }

    // Helper method to create an Album object with user input
    private static Main createAlbum(Scanner scanner, int albumNumber) {
        System.out.println("\nEnter details for Album " + albumNumber + ":");

        System.out.print("Enter title: ");
        String title = scanner.nextLine();

        System.out.print("Enter performer: ");
        String performer = scanner.nextLine();

        System.out.print("Enter genre: ");
        String genre = scanner.nextLine();

        System.out.print("Enter number of songs: ");
        int numberOfSongs = scanner.nextInt();
        scanner.nextLine(); // Consume newline character

        return new Main(title, performer, genre, numberOfSongs);
    }
}
